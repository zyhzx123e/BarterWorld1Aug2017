package webview_webapp.jason.webview;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends AppCompatActivity {


    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        WebView wv = (WebView)findViewById(R.id.wv_main);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);


        wv.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);

                if(!Common.connectionAvailable((MainActivity.this))){

                    Intent i = new Intent(MainActivity.this,ErrorActivity.class);
                    i.putExtra("MSG",getString(R.string.ErrorActivity_connection_str));
                    startActivity(i);
                    finish();


                }

                pd=new ProgressDialog(MainActivity.this);
                pd.setMessage(getString(R.string.main_activity_loading_string));
                pd.show();
            }


            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                if(pd!=null)
                    pd.dismiss();


            }


            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                Intent i = new Intent(MainActivity.this,ErrorActivity.class);
                i.putExtra("MSG",getString(R.string.error_activity_somethingwrong)+error.toString());
                startActivity(i);
                finish();

            }


            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {

                view.loadUrl(request.getUrl().toString());
                return super.shouldOverrideUrlLoading(view, request);
            }
        });

wv.loadUrl("http://ins-fashion.com.my/shop/index.php");
    }

    @Override
    public void onBackPressed() {

        WebView wv = (WebView)findViewById(R.id.wv_main);
       if(wv.canGoBack()){
           wv.goBack();
       }else {
           super.onBackPressed();
       }

    }
}
