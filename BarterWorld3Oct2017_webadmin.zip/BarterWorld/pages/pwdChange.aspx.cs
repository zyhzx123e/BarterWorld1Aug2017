﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using System.Data.SqlClient;
using System.Configuration;
using System.Net.Mail;
using FireSharp.Config;
using FireSharp.EventStreaming;
using FireSharp.Exceptions;
using FireSharp.Interfaces;
using FireSharp.Response;
using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using System.Threading;

public partial class pwdChange : System.Web.UI.Page
{
    public int count = 0;
    private static FireSharp.FirebaseClient _client = db_connection.getFirebaseClientRef();
    public string admin_id_get;
    public string admin_pwd_get;
    public string admin_loggedin_get;

    _user userObject = new _user();


    protected void Page_Load(object sender, EventArgs e)
    {

      
        if (!IsPostBack)
        {
          

            admin_id_get = Session["id"].ToString();
            admin_pwd_get = Session["pwd"].ToString();
            admin_loggedin_get = Session["loggedin"].ToString();
        }
      //  if (admin_id_get == null) { Response.Redirect("~/pages/login.aspx"); }
    }

    protected async void changePassword( string oldPassword ,string newPassword)
    {
        
       
        FirebaseResponse response = await _client.GetAsync("Admin");
        administrator ad = response.ResultAs<administrator>(); //The response will contain the data being retreived
        string getidstr = ad.adminid;
        string getpwdstr = ad.adminpwd;

 
            if (oldPassword.Equals(getpwdstr))
            {

                var admin = new administrator
                {
                    adminid = "admin1",
                    adminpwd = newPassword
                };

                FirebaseResponse response_update = await _client.UpdateAsync("Admin", admin);
                administrator admin_updated = response_update.ResultAs<administrator>(); //The response will contain the data written


              

                System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Hi Admin, You Have Successfully Changed Password!');", true);

                sendEmail(newPassword);
                 System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('You Have Been Logged out!(Password Change Detection)');", true);


                 Thread.Sleep(3000); 
                Response.Redirect("~/pages/login.aspx");
                Response.Write("changed pwd: " + admin_updated.adminpwd);

            }
            else
            {
            
                
                System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Sorry, You have entered wrong admin password !');", true);

            }

  
     
        
    }

    private void sendEmail(string newPwd) {

        /*"barterworld2017@gmail.com", "zyhzx123e"*/
        string _id = "barterworld2017@gmail.com";
        string _password = "zyhzx123e";
        string subject = "Barter World Admin Password Changed!!! ->  -Zhang Yu Hao Project- @2017 APU Zhang Yu Hao ";
        string body = "Hi Admin Zhang Yu Hao! Your Admin Panel Password has just been changed! Your<br/>New Password : <b>" + newPwd + "</b>. This is an auto-generated non-reply email<br/><hr/> <br/><Barter World>  --Zhang Yu Hao          [TP037390]  zyh860@gmail.com<br/><br/> <br/><hr/>All Rights Reserved || Barter World @ 2017 || Asia Pacific University || UC3F1706IT(MBT)";
        string smtpAddress = "smtp.gmail.com";
        bool enableSSL = true;


        try
        {

         
            using (MailMessage mail = new MailMessage())
            {

                mail.From = new MailAddress(_id);
                mail.Sender = new MailAddress(_id);
                mail.To.Add("425352086@qq.com");
                mail.Subject = subject;
                mail.Body = body;
                mail.IsBodyHtml = true;
                mail.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;

                // Can set to false, if you are sending pure text.

                // mail.Attachments.Add(new Attachment("E:\\ss\\ss\\ss\\.....txt"));


                using (SmtpClient smtp = new SmtpClient(smtpAddress, 587))
                {
                    smtp.Credentials = new System.Net.NetworkCredential(_id, _password);
                    smtp.EnableSsl = enableSSL;
                    smtp.Send(mail);
                    smtp.Timeout = 100000;
                }
            }

            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Check Your Searching Around Email and get the random generated 4 digit code for validation');", true);

         


        }
        catch (Exception ex)
        {
            msg.Text = "Could not send email\n\n" + ex.ToString();
        }

    }

    protected async void change_password_btn_Click(object sender, EventArgs e)
    {

        string admin_id = admin_id_get;
        string admin_old_password = old_pass.Text.ToString().Trim();
        string admin_new_password = new_pass.Text.ToString().Trim();
        string admin_verify_new_password = verify_new_pass.Text.ToString().Trim();


        if (admin_new_password.Equals(admin_verify_new_password))
        {
            changePassword( admin_old_password, admin_new_password);
        }
        else {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Both Password Must be the same!');", true);

        }


       
    }
 

    protected void emptyForm()
    {
        old_pass.Text = "";
        new_pass.Text = "";
        verify_new_pass.Text = "";
    }
}