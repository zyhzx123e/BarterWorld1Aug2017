﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using System.Data.SqlClient;
using System.Configuration;

using FireSharp.Config;
using FireSharp.EventStreaming;
using FireSharp.Exceptions;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using System.Text;
using System.Net;
using System.IO;
using System.Diagnostics;

public partial class pages_common_login : System.Web.UI.Page
{

   // protected const string BasePath = "https://barterworld-ad75e.firebaseio.com/";
    //protected const string FirebaseSecret = "u8XCtop3XnzEmcmm9egRhLykr6UofkSREugvQsaL";
    private static FireSharp.FirebaseClient _client = db_connection.getFirebaseClientRef();


    protected void Page_Load(object sender, EventArgs e)
    {

     
    }
   
    protected async void log_Click(object _sender, EventArgs e) {
        Response.Write("888");

/*
          var todo = new administrator {
                adminid = "admin1",
                adminpwd = "123"
            };
          SetResponse response = await _client.SetAsync("Admin", todo);
          administrator result = response.ResultAs<administrator>();
          Response.Write("888" + result.adminid); //The result will contain the child name of the new data that was added


         */


        FirebaseResponse response = await _client.GetAsync("Admin");
        administrator todo = response.ResultAs<administrator>(); //The response will contain the data being retreived
        string getidstr = todo.adminid;
        string getpwdstr = todo.adminpwd;


        
        try
        {
            Response.Write("888");
            
            string input_code = iDNumber.Text;
            string input_pass = password.Text;
            if (string.IsNullOrEmpty(input_code) || string.IsNullOrEmpty(input_pass))
            {
                System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Admin Id and Password Can not be empty!');", true);
              
            }
            else
            {
               
               if ( input_code.Equals(getidstr) && input_pass.Equals(getpwdstr))
                 {
                    
                     /*
                      Cookies

  SET :

  HttpCookie cookName = new HttpCookie("Name");
  cookName.Value = "Pandian"; 
  GET :

  string name = Request.Cookies["Name"].Value;
                    
                      */
                 /*    HttpCookie cookie_adminid = new HttpCookie("id");
                     cookie_adminid.Value = input_code;

                     HttpCookie cookie_adminpwd = new HttpCookie("pwd");
                     cookie_adminid.Value = input_pass;

                     HttpCookie cookie_admin_loggedin = new HttpCookie("loggedin");
                     cookie_admin_loggedin.Value = "true";*/
                  
                   
                 

               /*    Debug.WriteLine("login-page-Cookies id:" + Request.Cookies["id"]);
                   Debug.WriteLine("login-page-Cookies pwd:" + Request.Cookies["pwd"]);
                   Debug.WriteLine("login-page-Cookies loggedin:" + Request.Cookies["loggedin"]);
*/


                     /*System.Web.HttpContext.Current.Session["id"] = input_code;

                     System.Web.HttpContext.Current.Session["pwd"] = input_pass;
                     System.Web.HttpContext.Current.Session["loggedin"] = "true";*/
                     Session["id"] = input_code;

                    Session["pwd"] = input_pass;
                    Session["loggedin"] = "true";

                   Debug.WriteLine("login-page-Session id:" + Session["id"]);
                   Debug.WriteLine("login-page-Session pwd:" + Session["pwd"]);
                   Debug.WriteLine("login-page-Session loggedin:" + Session["loggedin"]);
                   
                
                   // Server.Transfer("Home.aspx");
                  Response.Redirect("Home.aspx",false);
                }
                else
                {

                    System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Access Denied!');", true);
                }
            }

        }
        catch (Exception ex)
        {

            Debug.WriteLine(ex.Message);
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('The login process was unsuccessful, for more information please contact the administrator.');", true);
           
             }
    
    }

     

    protected void register_Click(object sender, EventArgs e)
    {
        Response.Redirect("register.aspx");
    }
   // List<barter> barter_list = new List<barter>();
    /*
    protected async void redirect_home(object sender, EventArgs e)
    {

        var json = Newtonsoft.Json.JsonConvert.SerializeObject(new
        {
            barter_img = "https://i.imgur.com/5WXYz4M.png",
            description = "test",

            latitude = "12",
            like_count = "2",
            longitude = "12",
            time = "121",
            title = "test",
            type = "test",
            uid = "12131231",
            username = "test",
            value = "test"
        });
        var request = WebRequest.CreateHttp("https://barterworld-ad75e.firebaseio.com/Barter_Posts/.json");
        request.Method = "POST";
        request.ContentType = "application/json";
        var buffer = Encoding.UTF8.GetBytes(json);
        request.ContentLength = buffer.Length;
        request.GetRequestStream().Write(buffer, 0, buffer.Length);
        var response = request.GetResponse();
        json = (new StreamReader(response.GetResponseStream())).ReadToEnd();
        // TODO: parse response (contained in `json` variable) as appropriate
        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('" + json + "');", true);
           
           
        }*/
      
}