﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using System.Data.SqlClient;
using System.Configuration;


using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using System.Diagnostics;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using System.Text;

public partial class pages_Home : System.Web.UI.Page
{

    public List<barter> barter_get;


    public string[] lat_array;
    public string[] long_array;
    public string[] barter_name_array;
    public string[] b_img_array;
    public string[] b_desc_array;
    public JavaScriptSerializer javaSerial = new JavaScriptSerializer();




    protected override void OnInit(EventArgs e)
    {
        barter_get = new List<barter>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Barter_Posts/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            barter st = JsonConvert.DeserializeObject<barter>(x.Value.ToString());
            st.ref_id = x.Name;

            barter_get.Add(st);

        }

        lat_array = new string[barter_get.Count];
        long_array = new string[barter_get.Count];
        barter_name_array = new string[barter_get.Count];
        b_img_array = new string[barter_get.Count];
        b_desc_array = new string[barter_get.Count];
        for (int i = 0; i < barter_get.Count; i++)
        {
            lat_array[i] = barter_get[i].latitude;
            long_array[i] = barter_get[i].longitude;
            barter_name_array[i] = barter_get[i].title;
            b_img_array[i] = barter_get[i].barter_img;
            b_desc_array[i] = barter_get[i].description;
            // Debug.WriteLine("Name:" + barter_name_array[i] + " Latitude:" + lat_array[i] +"  Longitude: "+long_array[i]);

        }

        List<barter> lst = new List<barter>();

        for (int i = 0; i < barter_get.Count; i++)
        {
            lst.Add(new barter() { title = barter_get[i].title, barter_img = barter_get[i].barter_img });

        }


        ///////////////////////////////////////above set the location of the map
    }



    protected void loop_map_locations(object sender, EventArgs e)
    {

        barter_get = new List<barter>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Barter_Posts/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            barter st = JsonConvert.DeserializeObject<barter>(x.Value.ToString());
            st.ref_id = x.Name;

            barter_get.Add(st);

        }

        lat_array = new string[barter_get.Count];
        long_array = new string[barter_get.Count];
        barter_name_array = new string[barter_get.Count];
        b_img_array = new string[barter_get.Count];
        b_desc_array = new string[barter_get.Count];
        for (int i = 0; i < barter_get.Count; i++)
        {
            lat_array[i] = barter_get[i].latitude;
            long_array[i] = barter_get[i].longitude;
            barter_name_array[i] = barter_get[i].title;
            b_img_array[i] = barter_get[i].barter_img;
            b_desc_array[i] = barter_get[i].description;
            // Debug.WriteLine("Name:" + barter_name_array[i] + " Latitude:" + lat_array[i] + "  Longitude: " + long_array[i]);

        }





        List<barter> lst = new List<barter>();

        for (int i = 0; i < barter_get.Count; i++)
        {
            lst.Add(new barter() { title = barter_get[i].title, barter_img = barter_get[i].barter_img });

        }

        myRepeater.DataSource = lst;
        myRepeater.DataBind();
    }



    protected void Page_Load(object sender, EventArgs e)
    {

        barter_get = new List<barter>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Barter_Posts/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            barter st = JsonConvert.DeserializeObject<barter>(x.Value.ToString());
            st.ref_id = x.Name;

            barter_get.Add(st);

        }

        lat_array = new string[barter_get.Count];
        long_array = new string[barter_get.Count];
        barter_name_array = new string[barter_get.Count];
        b_img_array = new string[barter_get.Count];
        b_desc_array = new string[barter_get.Count];
        for (int i = 0; i < barter_get.Count; i++)
        {
            lat_array[i] = barter_get[i].latitude;
            long_array[i] = barter_get[i].longitude;
            barter_name_array[i] = barter_get[i].title;
            b_img_array[i] = barter_get[i].barter_img;
            b_desc_array[i] = barter_get[i].description;
        }






        List<barter> lst = new List<barter>();

        for (int i = 0; i < barter_get.Count; i++)
        {
            lst.Add(new barter() { title = barter_get[i].title, barter_img = barter_get[i].barter_img });

        }

        myRepeater.DataSource = lst;
        myRepeater.DataBind();

        ///////////////////////////////////////above set the location of the map



        Debug.WriteLine("home-Cookies id:" + Request.Cookies["id"]);
        Debug.WriteLine("home-Cookies pwd:" + Request.Cookies["pwd"]);
        Debug.WriteLine("home-Cookies loggedin:" + Request.Cookies["loggedin"]);

        Debug.WriteLine("home-Session id:" + Session["id"]);
        Debug.WriteLine("home-Session pwd:" + Session["pwd"]);
        Debug.WriteLine("home-Session loggedin:" + Session["loggedin"]);


        if (Session["id"] != null)
        {
            username_lbl.Text = Session["id"].ToString();
            //retreive user data from session and display its name on the screen
        }
        else
        {
            //non_register_user
            Response.Redirect("~/pages/login.aspx");

        }

    }

    public String SendNotificationFromFirebaseCloud()
    {
        var result = "-1";
        var webAddr = "https://fcm.googleapis.com/fcm/send";

        var httpWebRequest = (HttpWebRequest)WebRequest.Create(webAddr);
        httpWebRequest.ContentType = "application/json";
        httpWebRequest.Headers.Add(string.Format("Authorization: key={0}", "AIzaSyBIAs6JPAQyP-IyDoGalw2eYfQYPhw7EpA"));

        httpWebRequest.Method = "POST";
        httpWebRequest.UseDefaultCredentials = true;
        ////clBdOhRikvk:APA91bGSdT6Z4J-FE5thJ7mdVxGHMgybASVaVFEdVVQOCSExJVwCqrTYL_3oqn-v8yIov7tQsAogfYTBVVpxkOSCXz2AIhTeW_GHGwa9jewiMN3_KPY29MjbqaxqNxeotZ5UMQBer2gN
        using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
        {
            //string json = "{\"to\": \"/topics/news\",\"notification\": {\"body\": \"New news added in application!\",\"title\":\"" + Your_Notif_Title + "\",}}";
            string json = "{\"to\": \"clBdOhRikvk:APA91bGSdT6Z4J-FE5thJ7mdVxGHMgybASVaVFEdVVQOCSExJVwCqrTYL_3oqn-v8yIov7tQsAogfYTBVVpxkOSCXz2AIhTeW_GHGwa9jewiMN3_KPY29MjbqaxqNxeotZ5UMQBer2gN\",\"data\": {\"id\":1,},\"notification\": {\"body\": \"" + txt_admin.Text.ToString() + "\",\"title\":\"Admin Message\",\"sound\":\"default\",\"priority\":\"high\"}}";

            streamWriter.Write(json);
            streamWriter.Flush();
        }

        var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
        using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
        {
            result = streamReader.ReadToEnd();
        }
        return result;
    }



    //-----------------------------------



    protected void btn_send_admin_txt_click(object sender, EventArgs e)
    {


        SendNotificationFromFirebaseCloud();


    }





    protected void serviceLinkBtn_Click(object sender, EventArgs e)
    {

    }
}