﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;

using System.Data;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System.Drawing;
using FireSharp.Response;


public partial class viewCustomer : System.Web.UI.Page
{

    public List<_user> user_get;
    public string[] name_array;


    protected void Page_Load(object sender, EventArgs e)
    {

      
////////////////////////////////////calling api
        if (Session["id"] == null)
        {

            /*
             c# - How to access session variables from any class in ASP.NET? - Stack Overflow. 2016. 
             * c# - How to access session variables from any class in ASP.NET? - Stack Overflow. 
             * [ONLINE] Available at: http://stackoverflow.com/questions/621549/how-to-access-session-variables-from-any-class-in-asp-net. [Accessed 01 Nov 2017].
             */

            Response.Redirect("~/pages/login.aspx");
        }



        if(!IsPostBack)
        {
            populate_items();



            user_get = new List<_user>();

            var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/.json"));
            http.Accept = "application/json";
            http.ContentType = "application/json";
            http.Method = "GET";

            var response = http.GetResponse();

            var stream = response.GetResponseStream();
            var sr = new StreamReader(stream);
            var content = sr.ReadToEnd();

            dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

            foreach (JProperty x in (JToken)result)
            {
                // Debug.WriteLine( x.Value.ToString());
                Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
                _user st = JsonConvert.DeserializeObject<_user>(x.Value.ToString());
                st.uid = x.Name;


                user_get.Add(st);

            }

            name_array = new string[user_get.Count];
            for (int i = 0; i < user_get.Count; i++)
            {
                name_array[i] = user_get[i].user_name;
                Debug.WriteLine("Name:" + name_array[i]);

            }


            foreach (string name in name_array)
            {
                namesDropList.Items.Add(new ListItem(name));
            }

        }


     
       
    }


    


    protected void displayAllCustomer(object sender, EventArgs e)
    {
        displayAllUser();
    }

    protected void displayAllUser()
    {
        populate_items();
    }


     
  

    public List<_user> getUsers()
    {

        List<_user> user_get = new List<_user>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            _user st = JsonConvert.DeserializeObject<_user>(x.Value.ToString());
            st.uid = x.Name;

            user_get.Add(st);
            
        }



        return user_get;
    }



    public List<_user> getUsers(string user_name)
    {

        List<_user> user_get = new List<_user>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            _user st = JsonConvert.DeserializeObject<_user>(x.Value.ToString());
            st.uid = x.Name;

            if(st.user_name.Equals(user_name)){
                user_get.Add(st);
            }


        }


        return user_get;
    }



    public string convert_pwd_asterisk(string str){
        int count = 0;
        foreach (char c in str)
        {
           count++;
        }

        string pwd_as="";

        for (int i = 0; i < count;i++ )
        {
            pwd_as += @"*";

        }
        return pwd_as;


    }


    protected void populate_items()
    {


        Table userTable = new Table(); userTable.CssClass = "table table-bordered table-hover table-striped table-responsive";

        TableHeaderRow thr = new TableHeaderRow();
        TableHeaderCell thc_image = new TableHeaderCell(); thc_image.Text = "User Profile"; thr.Cells.Add(thc_image);
        TableHeaderCell thc_name = new TableHeaderCell(); thc_name.Text = "User Name"; thr.Cells.Add(thc_name);

        TableHeaderCell thc_email = new TableHeaderCell(); thc_email.Text = "User Email"; thr.Cells.Add(thc_email);
        TableHeaderCell thc_pwd = new TableHeaderCell(); thc_pwd.Text = "User Password"; thr.Cells.Add(thc_pwd);
      
        /*
         How to: Add Rows and Cells Dynamically to a Table Web Server Control. 2016.
         * How to: Add Rows and Cells Dynamically to a Table Web Server Control. 
         * [ONLINE] Available at: https://msdn.microsoft.com/en-us/library/7bewx260.aspx. [Accessed 18 September 2017].
         */
        TableHeaderCell thc_trading = new TableHeaderCell(); thc_trading.Text = "View Password"; thr.Cells.Add(thc_trading);
        userTable.Rows.Add(thr);

        foreach (_user u in getUsers())
        {
            TableRow newRow = new TableRow();
            TableCell imgCell = new TableCell();
            imgCell.Text = string.Format("<img src='" + u.user_img + "' class='center-block' runat='server' Height='120px' Width='150px'/>"); newRow.Cells.Add(imgCell);

            TableCell nameCell = new TableCell(); nameCell.Text = u.user_name; newRow.Cells.Add(nameCell);

            TableCell email_Cell = new TableCell(); email_Cell.Text = u.user_email; newRow.Cells.Add(email_Cell);

            TableCell pwdCell = new TableCell(); pwdCell.Text = convert_pwd_asterisk(u.user_pwd); newRow.Cells.Add(pwdCell);
          
            TableCell tradingBtnCell = new TableCell();


            Button viewPwdBtn = new Button();
            viewPwdBtn.ID = u.uid.ToString();//****key to transfer item item later in to next page

            Session["user_uid"] = u.uid.ToString();
            
            viewPwdBtn.Width = 100;
            viewPwdBtn.Height = 100;
            viewPwdBtn.Enabled = false;
           
            viewPwdBtn.BackColor = Color.Gray;
            viewPwdBtn.ForeColor = Color.Green;
            viewPwdBtn.Text = "View Password";
            viewPwdBtn.CssClass = "btn-sm btn-danger";
            tradingBtnCell.Controls.Add(viewPwdBtn);

            viewPwdBtn.Click += new EventHandler(this.pwd_Btn_Click);

            if (Session["id"] != null)
            {

                newRow.Cells.Add(tradingBtnCell);
            }
            else
            {

                thc_trading.Visible = false;
            }


            userTable.Rows.Add(newRow);
        }
        user_ph.Controls.Clear();
        user_ph.Controls.Add(userTable);

    }








    protected void populate_users(string u_name)
    {


        Table userTable = new Table(); userTable.CssClass = "table table-bordered table-hover table-striped table-responsive";

        TableHeaderRow thr = new TableHeaderRow();
        TableHeaderCell thc_image = new TableHeaderCell(); thc_image.Text = "User Profile"; thr.Cells.Add(thc_image);
        TableHeaderCell thc_name = new TableHeaderCell(); thc_name.Text = "User Name"; thr.Cells.Add(thc_name);

        TableHeaderCell thc_email = new TableHeaderCell(); thc_email.Text = "User Email"; thr.Cells.Add(thc_email);
        TableHeaderCell thc_pwd = new TableHeaderCell(); thc_pwd.Text = "User Password"; thr.Cells.Add(thc_pwd);

        /*
         How to: Add Rows and Cells Dynamically to a Table Web Server Control. 2016.
         * How to: Add Rows and Cells Dynamically to a Table Web Server Control. 
         * [ONLINE] Available at: https://msdn.microsoft.com/en-us/library/7bewx260.aspx. [Accessed 18 September 2017].
         */
        TableHeaderCell thc_trading = new TableHeaderCell(); thc_trading.Text = "View Password"; thr.Cells.Add(thc_trading);
        userTable.Rows.Add(thr);

        foreach (_user u in getUsers(u_name))
        {
            TableRow newRow = new TableRow();
            TableCell imgCell = new TableCell();
            imgCell.Text = string.Format("<img src='" + u.user_img + "' class='center-block' runat='server' Height='120px' Width='150px'/>"); newRow.Cells.Add(imgCell);

            TableCell nameCell = new TableCell(); nameCell.Text = u.user_name; newRow.Cells.Add(nameCell);

            TableCell email_Cell = new TableCell(); email_Cell.Text = u.user_email; newRow.Cells.Add(email_Cell);

            TableCell pwdCell = new TableCell(); pwdCell.Text = convert_pwd_asterisk(u.user_pwd); newRow.Cells.Add(pwdCell);

            TableCell tradingBtnCell = new TableCell();


            Button viewPwdBtn = new Button();
            viewPwdBtn.ID = u.uid.ToString();//****key to transfer item item later in to next page

            Session["user_uid"] = u.uid.ToString();

            viewPwdBtn.Width = 100;
            viewPwdBtn.Height = 100;
            viewPwdBtn.Enabled = false;
            viewPwdBtn.ToolTip = u.user_pwd;
            viewPwdBtn.BackColor = Color.Gray;
            viewPwdBtn.ForeColor = Color.Green;
            viewPwdBtn.Text = "View Password";
            viewPwdBtn.CssClass = "btn-sm btn-danger";
            tradingBtnCell.Controls.Add(viewPwdBtn);

            viewPwdBtn.Click += new EventHandler(this.pwd_Btn_Click);

            if (Session["id"] != null)
            {

                newRow.Cells.Add(tradingBtnCell);
            }
            else
            {

                thc_trading.Visible = false;
            }


            userTable.Rows.Add(newRow);
        }
        user_ph.Controls.Clear();
        user_ph.Controls.Add(userTable);

    }



    private void MessageBoxShow(string message)
    {
        this.AlertBoxMessage.InnerText = message;
        this.AlertBox.Visible = true;
    }

    private void admin_verification_box_show()
    {
        this.verification_box.Visible = true;


    }
    private static FireSharp.FirebaseClient _client = db_connection.getFirebaseClientRef();



    protected async void verify_admin_identity(object sender, EventArgs e)
    {

        FirebaseResponse response = await _client.GetAsync("Admin");
        administrator todo = response.ResultAs<administrator>(); //The response will contain the data being retreived
        string getidstr = todo.adminid;
        string getpwdstr = todo.adminpwd;

        if ((txt_admin_pwd_verify.Text.ToString()).Equals(getpwdstr))
        {


            string selected_user_uid= Session["selected_user_to_view"].ToString();


              var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/"+selected_user_uid+"/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var res = http.GetResponse();

        var stream = res.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        _user result = JsonConvert.DeserializeObject<_user>(content);





        MessageBoxShow("The Current Password for <" + Session["selected_user_to_view"].ToString() + ">User:[" + result.user_name + "] is : " + result.user_pwd);
            this.verification_box.Visible = false;

        }
        else {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Sorry! Admin Verification Failed!');", true);
            this.verification_box.Visible = false;

        }

    
    
    }

    protected void pwd_Btn_Click(object sender, EventArgs e) {

         Button user_btn = sender as Button;
         Session["selected_user_to_view"] = user_btn.ID;



         var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/" + Session["selected_user_to_view"].ToString()+ "/.json"));
         http.Accept = "application/json";
         http.ContentType = "application/json";
         http.Method = "GET";

         var res = http.GetResponse();

         var stream = res.GetResponseStream();
         var sr = new StreamReader(stream);
         var content = sr.ReadToEnd();

         _user result = JsonConvert.DeserializeObject<_user>(content);

         System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('The Selected User["+result.user_name+"] Password is:"+result.user_pwd+"');", true);
          
         populate_items();

        admin_verification_box_show();
       
    }









    protected void namesDropList_SelectedIndexChanged(object sender, EventArgs e)
    {
        populate_users((namesDropList.SelectedValue).ToString().Trim());
    }

}