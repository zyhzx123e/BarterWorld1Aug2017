﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using System.Data.SqlClient;
using System.Configuration;


using System.Collections.Generic;

using System.Data.SqlClient;
using System.Configuration;

using Firebase1.Storage;
using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using System.Drawing;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Firebase.Storage;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;

using FireSharp.Response;


using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using Newtonsoft.Json.Linq;
using CloudinaryDotNet.Actions;
using CloudinaryDotNet;
using System.Web.Script.Serialization;

public partial class servicePost : System.Web.UI.Page
{



    public List<barter> barter_get;

    public string[] lat_array;
    public string[] long_array;
    public string[] barter_name_array;
    public string[] b_img_array;
    public string[] b_desc_array;
    public JavaScriptSerializer javaSerial = new JavaScriptSerializer();




    protected override void OnInit(EventArgs e)
    {/*
      * 
      Init is a good place to add dynamic controls to the page or user control 
      * If can, then those controls will have their ViewState restored automatically during postbacks 
      * 
      */

        base.OnInit(e);


        try
        {

            string admin_id = Session["id"].ToString();
        }
        catch (Exception ex)
        {
            Response.Redirect("~/pages/signOut.aspx");
        }

        if (!IsPostBack)
        {

            api_bind_list();
        }
     


        barter_get = new List<barter>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Barter_Posts/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            barter st = JsonConvert.DeserializeObject<barter>(x.Value.ToString());
            st.ref_id = x.Name;

            barter_get.Add(st);

        }

        lat_array = new string[barter_get.Count];
        long_array = new string[barter_get.Count];
        barter_name_array = new string[barter_get.Count];
        b_img_array = new string[barter_get.Count];
        b_desc_array = new string[barter_get.Count];
        for (int i = 0; i < barter_get.Count; i++)
        {
            lat_array[i] = barter_get[i].latitude;
            long_array[i] = barter_get[i].longitude;
            barter_name_array[i] = barter_get[i].title;
            b_img_array[i] = barter_get[i].barter_img;
            b_desc_array[i] = barter_get[i].description;
            Debug.WriteLine("Name:" + barter_name_array[i] + " Latitude:" + lat_array[i] + "  Longitude: " + long_array[i]);

        }





        ///////////////////////////////////////above set the location of the map
    }



    protected void save_current_info(object sender, EventArgs e)
    {


        Session["selected_latitude"] = this.txt_lat.Text.ToString();
        Session["selected_longitude"] = this.txt_long.Text.ToString();

        Debug.WriteLine("AJAX Passed back to c# selected latitude:" + Session["selected_latitude"].ToString());


        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Hi Admin selected lat: " + Session["selected_latitude"].ToString() + ", long:" + Session["selected_longitude"] .ToString()+ "');", true);
           
      //  Session["selected_latitude"] = this.txt_lat.Text.ToString();
       // Session["selected_longitude"] = this.txt_long.Text.ToString();


    }



    protected void Page_Load(object sender, EventArgs e)
    {


        if (Session["id"] == null)
        {


            Response.Redirect("~/pages/login.aspx");
        }
       
    }
   
    protected void bind_uid_user(object sender, EventArgs e)
    {

        List<String> user_uid_List = new List<String>();
        List<String> user_username_List = new List<String>();

        List<_user> user_list = new List<_user>();



        //*********************************************call api
        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            _user st = JsonConvert.DeserializeObject<_user>(x.Value.ToString());
            st.uid = x.Name;

            user_list.Add(st);

        }
        //******************************************8**call api



        foreach (_user u in user_list)
        {
            user_uid_List.Add(u.uid);
            user_username_List.Add(u.user_name);
        }


        Session["selected_user_index"]=DropDownList_user.SelectedIndex.ToString();
        Session["selected_user_name"] = DropDownList_user.SelectedValue.ToString();

        
        Session["selected_user_uid"] = user_uid_List[DropDownList_user.SelectedIndex].ToString();
        //System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Hi Admin ,-: " + Session["selected_user_uid"].ToString() + "');", true);
        lbl_u_uid.Text = Session["selected_user_uid"].ToString();
    }



    public  void api_bind_list(){


        List<String> user_uid_List = new List<String>();
        List<String> user_username_List = new List<String>();

        List<_user> user_list = new List<_user>();



        //*********************************************call api
        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            _user st = JsonConvert.DeserializeObject<_user>(x.Value.ToString());
            st.uid = x.Name;

            user_list.Add(st);

        }
        //******************************************8**call api



        foreach(_user u in user_list){
            user_uid_List.Add(u.uid);
            user_username_List.Add(u.user_name);
        }



        List<String> barter_type_List = new List<String>();
        barter_type_List.Add("Services");
        barter_type_List.Add("Goods");


        /*
         
          DateTime now = DateTime.Now;
        CultureInfo culture = new CultureInfo("ar-SA"); // Saudi Arabia
        Thread.CurrentThread.CurrentCulture = culture;
        Console.WriteLine(now.ToString("yyyy-MM-ddTHH:mm:ss.fff"));
         
         */

        foreach (string name in user_username_List)
        {
            DropDownList_user.Items.Add(new ListItem(name));
        }


        foreach (string type in barter_type_List)
        {
            DropDownList_type.Items.Add(new ListItem(type));
        }
    
    }


    


     


    protected void emptyServicePopUpFrom()
    {
        txt_barter_name.Text = "";
        txt_description.Text = "";
       
    }



    protected void backBtn_Click(object sender, EventArgs e)
    {
        string chk_history = Session["visit_back_history"].ToString();


        if (chk_history.Equals("Services"))
        {
            Response.Redirect("Services.aspx");
        }
        else
        {
            Response.Redirect("goods.aspx");
        }
       

       
    }

    protected void test_Click(object sender, EventArgs e)
    {
        Session["selected_latitude"] = this.HiddenField_lat.Value.ToString();
        Session["selected_longitude"] = this.HiddenField_long.Value.ToString();

        Debug.WriteLine("AJAX Passed back to c# selected latitude:" + Session["selected_latitude"].ToString());


        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Hi Admin selected lat: " + Session["selected_latitude"].ToString() + ", long:" + Session["selected_longitude"].ToString() + "');", true);
    }

    protected void submit_item_btn_Click(object sender, EventArgs e)
    {
        Session["selected_latitude"] = this.HiddenField_lat.Value.ToString();
        Session["selected_longitude"] = this.HiddenField_long.Value.ToString();

        Debug.WriteLine("AJAX Passed back to c# selected latitude:" + Session["selected_latitude"].ToString());


        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Hi Admin selected lat: " + Session["selected_latitude"].ToString() + ", long:" + Session["selected_longitude"].ToString() + "');", true);
           

      


        Stream fs = FileUpload1.PostedFile.InputStream;
        BinaryReader br = new BinaryReader(fs);
        byte[] fileBytes = br.ReadBytes((Int32)fs.Length);

        string base64String = Convert.ToBase64String(fileBytes, 0, fileBytes.Length);
        img.ImageUrl = "data:image/png;base64," + base64String;
        img.Visible = true;
        Stream stream = new MemoryStream(fileBytes);

        DateTime now = DateTime.Now;

        Console.WriteLine(now.ToString("yyyy-MM-dd HH:mm:ss"));

        string download_url_str="";



        if (FileUpload1.PostedFile != null)
        {
            string s = @"" + FileUpload1.FileName;
            FileUpload1.PostedFile.SaveAs(Server.MapPath(s));
            var uploadParams = new ImageUploadParams()
            {
                File = new FileDescription(@"BarterWorld\pages\Customer\" + s + "")
            };
            var uploadResult = db_connection.cloudinary.Upload(uploadParams);


            var checkParams = new SortedDictionary<string, object>();
            checkParams.Add("public_id", uploadResult.PublicId);
            checkParams.Add("version", uploadResult.Version);
            checkParams.Add("signature", uploadResult.Signature);
            checkParams.Add("width", uploadResult.Width);
            checkParams.Add("height", uploadResult.Height);
            checkParams.Add("format", uploadResult.Format);
            checkParams.Add("resource_type", uploadResult.ResourceType);
            checkParams.Add("created_at", uploadResult.CreatedAt);
            checkParams.Add("bytes", uploadResult.Length);
            checkParams.Add("type", uploadResult.Info);
            checkParams.Add("url", uploadResult.Uri);
            checkParams.Add("secure_url", uploadResult.SecureUri);

            /*
              
              
              "public_id":"tquyfignx5bxcbsupr6a",
   "version":1375302801,
   "signature":"52ecf23eeb987b3b5a72fa4ade51b1c7a1426a97",
   "width":1920,
   "height":1200,
   "format":"jpg",
   "resource_type":"image",
   "created_at":"2017-07-31T20:33:21Z",
   "bytes":737633,
   "type":"upload",
   "url":
   "http://res.cloudinary.com/demo/image/upload/v1375302801/tquyfignx5bxcbsupr6a.jpg",
   "secure_url":
   "https://res.cloudinary.com/demo/image/upload/v1375302801/tquyfignx5bxcbsupr6a.jpg"
              
             */

            var api = new Api(db_connection.account);
            string expectedSign_json = api.SignParameters(checkParams);


            Debug.WriteLine("response_url:" + uploadResult.Uri);

            // cloudinaryResponse result = JsonConvert.DeserializeObject<cloudinaryResponse>(uploadResult.ToString());

            download_url_str = uploadResult.Uri.ToString();




        }



        var json = Newtonsoft.Json.JsonConvert.SerializeObject(new
        {
            barter_img = download_url_str,
            description = txt_description.Text.ToString(),

            latitude = Session["selected_latitude"].ToString(),
            like_count = "0",
            longitude = Session["selected_longitude"].ToString(),
            time = now.ToString("yyyy-MM-dd HH:mm:ss"),
            title = txt_barter_name.Text.ToString(),
            type = DropDownList_type.SelectedValue.ToString(),
            uid = Session["selected_user_uid"].ToString(),
            username = DropDownList_user.SelectedValue.ToString(),
            value = txt_value.Text.ToString()
        });
        var request = WebRequest.CreateHttp("https://barterworld-ad75e.firebaseio.com/Barter_Posts/.json");
        request.Method = "POST";
        request.ContentType = "application/json";
        var buffer = Encoding.UTF8.GetBytes(json);
        request.ContentLength = buffer.Length;
        request.GetRequestStream().Write(buffer, 0, buffer.Length);
        var response = request.GetResponse();
        json = (new StreamReader(response.GetResponseStream())).ReadToEnd();
        // TODO: parse response (contained in `json` variable) as appropriate

        Debug.WriteLine(json);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Hi Admin , You Have just Uploaded a new barter item " + txt_barter_name.Text.ToString() + " on name of " + Session["selected_user_name"].ToString() + " with uid " + Session["selected_user_uid"].ToString() + "');", true);
           
    }


    protected void back_Click(object sender, EventArgs e)
    {
        string chk_history = Session["visit_back_history"].ToString();


        if (chk_history.Equals("Services"))
        {
            Response.Redirect("Services.aspx");
        }else{
            Response.Redirect("goods.aspx");
        }
       
    }
}