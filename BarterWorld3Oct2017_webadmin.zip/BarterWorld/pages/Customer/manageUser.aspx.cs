﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Sql;
using System.Data;

using System.Data.SqlClient;
using System.Configuration;


using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using FireSharp.Response;
using CloudinaryDotNet.Actions;
using CloudinaryDotNet;
using System.Text;
public partial class manageUser : System.Web.UI.Page
{

    public List<_user> user_get;
    public string[] name_array;

    //3585 7007 6324 557
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["id"] == null)
        {
            Response.Redirect("~/pages/login.aspx");   /*
             c# - How to access session variables from any class in ASP.NET? - Stack Overflow. 2016. 
             * c# - How to access session variables from any class in ASP.NET? - Stack Overflow. 
             * [ONLINE] Available at: http://stackoverflow.com/questions/621549/how-to-access-session-variables-from-any-class-in-asp-net. [Accessed 01 Nov 2017].
             */
        }
        if(!IsPostBack)
        {

            user_get = new List<_user>();

            var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/.json"));
            http.Accept = "application/json";
            http.ContentType = "application/json";
            http.Method = "GET";

            var response = http.GetResponse();

            var stream = response.GetResponseStream();
            var sr = new StreamReader(stream);
            var content = sr.ReadToEnd();

            dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

            foreach (JProperty x in (JToken)result)
            {
                // Debug.WriteLine( x.Value.ToString());
                Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
                _user st = JsonConvert.DeserializeObject<_user>(x.Value.ToString());
                st.uid = x.Name;


                user_get.Add(st);

            }

            name_array = new string[user_get.Count];
            for (int i = 0; i < user_get.Count; i++)
            {
                name_array[i] = user_get[i].user_name;
               // Debug.WriteLine("Name:" + name_array[i]);

            }


            foreach (string name in name_array)
            {
                namesDropList.Items.Add(new ListItem(name));
            }
        }

       
    }

    public void load_click(object sender, EventArgs e) {

        user_get = new List<_user>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            _user st = JsonConvert.DeserializeObject<_user>(x.Value.ToString());
            st.uid = x.Name;


            user_get.Add(st);

        }
      


        Session["selected_user_name"] = namesDropList.SelectedValue.ToString();

        foreach (_user u in user_get)
        {
            if (u.user_name.Equals(Session["selected_user_name"].ToString()))
            {
                this.img.ImageUrl = u.user_img;
                this.uid_txt.Text = u.uid;
                this.txt_email.Text = u.user_email;
                this.txt_username.Text = u.user_name;
                this.txt_pwd.Text = u.user_pwd;

              //  Response.Redirect(Request.RawUrl);


                Session["user_uid_update"] = u.uid;
                Session["user_img_url_update"] = u.user_img;
                Session["user_username_update"] = u.user_name;
                Session["user_userpwd_update"] = u.user_pwd;
                Session["user_useremail_update"] = u.user_email;
            }
    
        
        }

     

        System.Threading.Thread.Sleep(2000);

        Debug.WriteLine("test Session:" + Session["user_img_url_update"].ToString());

        this.img.ImageUrl = Session["user_img_url_update"].ToString();
        this.uid_txt.Text = Session["user_uid_update"].ToString();
        this.txt_email.Text = Session["user_useremail_update"].ToString();
        this.txt_username.Text = Session["user_username_update"].ToString();
        this.txt_pwd.Text = Session["user_userpwd_update"].ToString();
    }

     
    

    
    
    /*
          Session["user_uid_update"] = u.uid;
          Session["user_img_url_update"] = u.user_img;
          Session["user_username_update"] = u.user_name;
          Session["user_userpwd_update"] = u.user_pwd;
          Session["user_useremail_update"] = u.user_email;*/
    protected void d_Click(object sender, EventArgs e)
    {
        MessageBoxShow("Are you sure you wanted to delete the selected User[" + Session["user_uid_update"].ToString() + "] : " + Session["user_username_update"] .ToString()+ "");
    }
    private void MessageBoxShow(string message)
    {
        this.AlertBoxMessage.InnerText = message;
        this.AlertBox.Visible = true;
    }
    protected void delete_Click(object sender, EventArgs e)
    {



        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/User/" + Session["user_uid_update"].ToString() + "/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "DELETE";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        this.AlertBox.Visible = false;

        System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('You have just Deleted User（" + Session["user_uid_update"].ToString() + "） : " + txt_username.Text.ToString() + ", You will be redirect to Home Page Soon');", true);


        Response.Redirect("~/pages/Home.aspx");


    }


    private static FireSharp.FirebaseClient _client = db_connection.getFirebaseClientRef();

    public string download_url_str = "";


    protected async void add_user_btn_Click(object sender, EventArgs e) {




        if (FileUpload2.HasFile)
        {
            string s = @"" + FileUpload2.FileName;
            FileUpload2.PostedFile.SaveAs(Server.MapPath(s));
            var uploadParams = new ImageUploadParams()
            {
                File = new FileDescription(@"BarterWorld\pages\Customer\" + s + "")
            };
            var uploadResult = db_connection.cloudinary.Upload(uploadParams);


            var checkParams = new SortedDictionary<string, object>();
            checkParams.Add("public_id", uploadResult.PublicId);
            checkParams.Add("version", uploadResult.Version);
            checkParams.Add("signature", uploadResult.Signature);
            checkParams.Add("width", uploadResult.Width);
            checkParams.Add("height", uploadResult.Height);
            checkParams.Add("format", uploadResult.Format);
            checkParams.Add("resource_type", uploadResult.ResourceType);
            checkParams.Add("created_at", uploadResult.CreatedAt);
            checkParams.Add("bytes", uploadResult.Length);
            checkParams.Add("type", uploadResult.Info);
            checkParams.Add("url", uploadResult.Uri);
            checkParams.Add("secure_url", uploadResult.SecureUri);

            /*
              
              
              "public_id":"tquyfignx5bxcbsupr6a",
   "version":1375302801,
   "signature":"52ecf23eeb987b3b5a72fa4ade51b1c7a1426a97",
   "width":1920,
   "height":1200,
   "format":"jpg",
   "resource_type":"image",
   "created_at":"2017-07-31T20:33:21Z",
   "bytes":737633,
   "type":"upload",
   "url":
   "http://res.cloudinary.com/demo/image/upload/v1375302801/tquyfignx5bxcbsupr6a.jpg",
   "secure_url":
   "https://res.cloudinary.com/demo/image/upload/v1375302801/tquyfignx5bxcbsupr6a.jpg"
              
             */

            var api = new Api(db_connection.account);
            string expectedSign_json = api.SignParameters(checkParams);


            Debug.WriteLine("response_url:" + uploadResult.Uri);

            // cloudinaryResponse result = JsonConvert.DeserializeObject<cloudinaryResponse>(uploadResult.ToString());

            download_url_str = uploadResult.Uri.ToString();


            Stream fs = FileUpload2.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(fs);
            byte[] fileBytes = br.ReadBytes((Int32)fs.Length);

            string base64String = Convert.ToBase64String(fileBytes, 0, fileBytes.Length);
            new_user_img.ImageUrl = "data:image/png;base64," + base64String;

            Stream stream = new MemoryStream(fileBytes);


        }
        else {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Please Select a profile picture!');", true);
       
        
        }

         

        if(!new_user_pwd.Text.ToString().Equals(new_user_pwd2.Text.ToString())){
            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Please ensure the both password are mathced!');", true);
       
        }else{
        
       

             Session["new_user_email"] = this.new_user_email.Text.ToString();
              Session["new_user_img"] = download_url_str;
              Session["new_user_name"] = this.new_user_name.Text.ToString();
           Session["new_user_pwd"]=this.new_user_pwd.Text.ToString();


        //////////////////////////////////img process

        var json = Newtonsoft.Json.JsonConvert.SerializeObject(new
        {
            user_email = this.new_user_email.Text.ToString(),
            user_img = download_url_str,
           user_name=this.new_user_name.Text.ToString(),
           user_pwd=this.new_user_pwd.Text.ToString()

          
        });
        var request = WebRequest.CreateHttp("https://barterworld-ad75e.firebaseio.com/User/.json");
        request.Method = "POST";
        request.ContentType = "application/json";
        var buffer = Encoding.UTF8.GetBytes(json);
        request.ContentLength = buffer.Length;
        request.GetRequestStream().Write(buffer, 0, buffer.Length);
        var response = request.GetResponse();
        json = (new StreamReader(response.GetResponseStream())).ReadToEnd();
        // TODO: parse response (contained in `json` variable) as appropriate
       Debug.WriteLine(json);


       System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Hi Admin, You have successfully created a new user[" + Session["new_user_name"] + "]');", true);
       

        //http://res.cloudinary.com/barterworld/image/upload/v1505614318/pro_ddcxbc.jpg

        }
    
    }

    protected async void save_Click(object sender, EventArgs e)
    {
        if (txt_username.Text != "" && txt_pwd.Text != "" && txt_email.Text != "")
        {

           

            if (FileUpload1.HasFile)
            {
                string s = @"" + FileUpload1.FileName;
                FileUpload1.PostedFile.SaveAs(Server.MapPath(s));
                var uploadParams = new ImageUploadParams()
                {
                    File = new FileDescription(@"BarterWorld\pages\Customer\" + s + "")
                };
                var uploadResult = db_connection.cloudinary.Upload(uploadParams);


                var checkParams = new SortedDictionary<string, object>();
                checkParams.Add("public_id", uploadResult.PublicId);
                checkParams.Add("version", uploadResult.Version);
                checkParams.Add("signature", uploadResult.Signature);
                checkParams.Add("width", uploadResult.Width);
                checkParams.Add("height", uploadResult.Height);
                checkParams.Add("format", uploadResult.Format);
                checkParams.Add("resource_type", uploadResult.ResourceType);
                checkParams.Add("created_at", uploadResult.CreatedAt);
                checkParams.Add("bytes", uploadResult.Length);
                checkParams.Add("type", uploadResult.Info);
                checkParams.Add("url", uploadResult.Uri);
                checkParams.Add("secure_url", uploadResult.SecureUri);

                /*
              
              
                  "public_id":"tquyfignx5bxcbsupr6a",
       "version":1375302801,
       "signature":"52ecf23eeb987b3b5a72fa4ade51b1c7a1426a97",
       "width":1920,
       "height":1200,
       "format":"jpg",
       "resource_type":"image",
       "created_at":"2017-07-31T20:33:21Z",
       "bytes":737633,
       "type":"upload",
       "url":
       "http://res.cloudinary.com/demo/image/upload/v1375302801/tquyfignx5bxcbsupr6a.jpg",
       "secure_url":
       "https://res.cloudinary.com/demo/image/upload/v1375302801/tquyfignx5bxcbsupr6a.jpg"
              
                 */

                var api = new Api(db_connection.account);
                string expectedSign_json = api.SignParameters(checkParams);


                Debug.WriteLine("response_url:" + uploadResult.Uri);

                // cloudinaryResponse result = JsonConvert.DeserializeObject<cloudinaryResponse>(uploadResult.ToString());

                download_url_str = uploadResult.Uri.ToString();


                Stream fs = FileUpload1.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(fs);
                byte[] fileBytes = br.ReadBytes((Int32)fs.Length);

                string base64String = Convert.ToBase64String(fileBytes, 0, fileBytes.Length);
                img.ImageUrl = "data:image/png;base64," + base64String;

                Stream stream = new MemoryStream(fileBytes);


            }



            string upload_img_url = "";

            if (!FileUpload1.HasFile || download_url_str == null || download_url_str == "")
            {

                upload_img_url = Session["user_img_url_update"].ToString();

            }
            else
            {
                upload_img_url = download_url_str;

            }


             /*
            Session["user_uid_update"] = u.uid;
            Session["user_img_url_update"] = u.user_img;
            Session["user_username_update"] = u.user_name;
            Session["user_userpwd_update"] = u.user_pwd;
            Session["user_useremail_update"] = u.user_email;*/


            var user = new _user
            {

                user_email=txt_email.Text.ToString(),
                user_img = upload_img_url,
                user_name= txt_username.Text.ToString(),
                user_pwd=txt_pwd.Text.ToString()

            };

            FirebaseResponse response_update = await _client.UpdateAsync("User/" + Session["user_uid_update"].ToString() + "", user);
            _user user_updated = response_update.ResultAs<_user>(); //The response will contain the data written


            Debug.WriteLine("json data: " + user_updated.user_name);

            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('You have just updated User（" + Session["user_uid_update"].ToString() + "） : " + txt_username.Text.ToString() + "');", true);





        }
        else {

            System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('Hi Admin, Please Fill in All the required info!');", true);
           
        }
    }










    
}