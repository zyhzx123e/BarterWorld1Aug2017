﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using System.Data.SqlClient;
using System.Configuration;
using FireSharp.Config;
using FireSharp.EventStreaming;
using FireSharp.Exceptions;
using FireSharp.Interfaces;
using FireSharp.Response;


using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using System.Drawing;
using System.Web.Script.Serialization;
using System.Net;
using System.Text;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;

public partial class pages_services : System.Web.UI.Page
{

    private static FireSharp.FirebaseClient _client = db_connection.getFirebaseClientRef();

     
    

     protected override void OnInit(EventArgs e)
    {

        base.OnInit(e);

        if (Session["id"] != null)
        {

            string user_id = Session["id"].ToString();

        }

        if (!IsPostBack)
        {
            //populate_items();
            Session["q_service"] = "";
          
            populate_items_sort(txt_service_sort.Text.Trim().ToString());
        }

        populate_items_sort(txt_service_sort.Text.Trim().ToString());

       
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    

    protected void populate_items_sort(object sender, EventArgs e)
    {
        Debug.WriteLine("Service update panel test");
         populate_items_sort(Session["q_service"].ToString());    
    }
 
    protected void populate_items_sort(string str_sort)
    {
        str_sort = Session["q_service"].ToString(); 
        Table itemTable = new Table(); itemTable.CssClass = "table table-bordered table-hover table-striped table-responsive";

        TableHeaderRow thr = new TableHeaderRow();
        TableHeaderCell thc_image = new TableHeaderCell(); thc_image.Text = "Image"; thr.Cells.Add(thc_image);
        TableHeaderCell thc_name = new TableHeaderCell(); thc_name.Text = "Name"; thr.Cells.Add(thc_name);

        TableHeaderCell thc_like = new TableHeaderCell(); thc_like.Text = "Liked Count"; thr.Cells.Add(thc_like);
        TableHeaderCell thc_price = new TableHeaderCell(); thc_price.Text = "Value"; thr.Cells.Add(thc_price);
        TableHeaderCell thc_item_type = new TableHeaderCell(); thc_item_type.Text = "Type"; thr.Cells.Add(thc_item_type);
        TableHeaderCell thc_desc = new TableHeaderCell(); thc_desc.Text = "Description"; thr.Cells.Add(thc_desc);
        TableHeaderCell thc_lat = new TableHeaderCell(); thc_lat.Text = "Longitude"; thr.Cells.Add(thc_lat);
        TableHeaderCell thc_long = new TableHeaderCell(); thc_long.Text = "Latitude"; thr.Cells.Add(thc_long);
        TableHeaderCell thc_addedby = new TableHeaderCell(); thc_addedby.Text = "Posted by"; thr.Cells.Add(thc_addedby);

        /*
         How to: Add Rows and Cells Dynamically to a Table Web Server Control. 2016.
         * How to: Add Rows and Cells Dynamically to a Table Web Server Control. 
         * [ONLINE] Available at: https://msdn.microsoft.com/en-us/library/7bewx260.aspx. [Accessed 18 September 2017].
         */
        TableHeaderCell thc_trading = new TableHeaderCell(); thc_trading.Text = "search"; thr.Cells.Add(thc_trading);
        itemTable.Rows.Add(thr);
        /*
         
<div style="text-align:center;width:100px;display:block;">First Image<img style="  height:100px;display:block;width:100px;" src="1.JPEG" ></img></div>         
         */
        foreach (barter item in getitems_sort(str_sort))
        {
            TableRow newRow = new TableRow();
            TableCell imgCell = new TableCell();
            imgCell.Text = string.Format("<img src='" + item.barter_img + "' class='center-block' runat='server' Height='120px' Width='150px'/>"); newRow.Cells.Add(imgCell);

            TableCell nameCell = new TableCell(); nameCell.Text = item.title; newRow.Cells.Add(nameCell);

            TableCell liek_count_Cell = new TableCell(); liek_count_Cell.Text = item.like_count; newRow.Cells.Add(liek_count_Cell);


            TableCell priceCell = new TableCell(); priceCell.Text = "$ " + (item.value).ToString(); newRow.Cells.Add(priceCell);
            TableCell itemTypeCell = new TableCell(); itemTypeCell.Text = item.type; newRow.Cells.Add(itemTypeCell);
            TableCell descCell = new TableCell(); descCell.Text = item.description; newRow.Cells.Add(descCell);
            TableCell longiCell = new TableCell(); longiCell.Text = item.longitude; newRow.Cells.Add(longiCell);
            TableCell latiCell = new TableCell(); latiCell.Text = item.latitude; newRow.Cells.Add(latiCell);
            TableCell addedBy = new TableCell(); addedBy.Text = (item.username).ToString(); newRow.Cells.Add(addedBy);

            TableCell tradingBtnCell = new TableCell();


            Button tradingBtn = new Button();
            tradingBtn.ID = item.ref_id.ToString();//****key to transfer item item later in to next page
            tradingBtn.Width = 100;
            tradingBtn.Height = 150;

            tradingBtn.BackColor = Color.Orange;
            tradingBtn.ForeColor = Color.MintCream;
            tradingBtn.Text = "Search";
            tradingBtn.CssClass = "btn-sm btn-warning";
            tradingBtnCell.Controls.Add(tradingBtn);

            tradingBtn.Click += new EventHandler(this.trade_Btn_Click);

            if (Session["id"] != null)
            {

                newRow.Cells.Add(tradingBtnCell);
            }
            else
            {

                thc_trading.Visible = false;
            }


            itemTable.Rows.Add(newRow);
        }
        services_ph.Controls.Clear();
        services_ph.Controls.Add(itemTable);

    }

    protected void btn_search_service(object sender , EventArgs e){


        Session["q_service"] = txt_service_sort.Text.Trim().ToString();
        populate_items_sort(txt_service_sort.Text.Trim().ToString());
       
    }

     

    protected void trade_Btn_Click(object sender, EventArgs e)
    {
        Button search_btn = sender as Button;
        Session["item_id"] = search_btn.ID;
        
        Response.Redirect("selling_followup.aspx"); 
    }

    protected void add_new_itemlem_Click(object sender, EventArgs e)
    {

    }
    public string RemoveNameSubstring(string name)
    {
        int index = name.IndexOf("/");
        string uniqueKey = (index < 0) ? name : name.Remove(index, "/".Length);
        return uniqueKey;


    }

    public async void getBarter(List<barter> list) {


        await _client.OnAsync("Barter_Posts/", (sender, args, context) =>
        {
            //Gets the Unique ID and deletes the any other string attached to it
            barter dataFromFB = new barter();//= args.Data;//.Remove(22, 4); 
            string paths = args.Path;
            string key = RemoveNameSubstring(paths);
            string uniqueKey = key.Split('/').Last();

            if (keyHolder_service.ContainsKey(uniqueKey))
            {
                keyHolder_service[uniqueKey] = dataFromFB.uid;
                list.Add(dataFromFB);
              //  AddToListView(dataFromFB);
            }
            else
            {
                keyHolder_service.Add(uniqueKey, dataFromFB.uid);
                //foreach (string value in keyHolder.Values)
              //  AddToListView(dataFromFB);
            }
        });
         

    }


    private static Dictionary<string, string> keyHolder_service = new Dictionary<string, string>();

    public List<barter> getitems(char type)
    {

        List<barter> barter_get = new List<barter>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Barter_Posts/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
           // Debug.WriteLine( x.Value.ToString());
              Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            barter st = JsonConvert.DeserializeObject<barter>(x.Value.ToString());
            st.ref_id = x.Name;
            if(st.type=="Services"){
            
            barter_get.Add(st);
            }
        }


        barter_get.Reverse();
                return barter_get;
    }



    public List<barter> getitems_sort(string sort)
    {
        List<barter> itemsList = new List<barter>();


        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Barter_Posts/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

        foreach (JProperty x in (JToken)result)
        {
            // Debug.WriteLine( x.Value.ToString());
            //  Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
            barter st = JsonConvert.DeserializeObject<barter>(x.Value.ToString());
            st.ref_id = x.Name;
            if (st.type == "Services" && (st.type.ToLower().Contains(sort.ToLower()) || st.title.ToLower().Contains(sort.ToLower()) || st.description.ToLower().Contains(sort.ToLower()) || st.latitude.ToLower().Contains(sort.ToLower()) || st.longitude.ToLower().Contains(sort.ToLower()) || st.like_count.ToLower().Contains(sort.ToLower()) || st.time.ToLower().Contains(sort.ToLower()) || st.username.ToLower().Contains(sort.ToLower()) || st.value.ToLower().Contains(sort.ToLower())))
            {

                itemsList.Add(st);
            }
        }


        itemsList.Reverse();

        return itemsList;
    }
     


    

   
    protected void add_new_itemlem_Command(object sender, CommandEventArgs e)
    {

    }
   

    protected void add_new_service_Click(object sender, EventArgs e)
    {

        string session_service = "Services";
        string session_good = "Goods";

        Session["visit_back_history"] = session_service;
        Response.Redirect("servicePost.aspx"); 

    }
}

