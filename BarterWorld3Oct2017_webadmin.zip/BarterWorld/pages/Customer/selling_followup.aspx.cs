﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

 
using Google.Apis.Drive.v2;
using Google.Apis.Auth.OAuth2;
using System.Threading;
using Google.Apis.Util.Store;
using Google.Apis.Services;
using Google.Apis.Drive.v2.Data;
using System.Collections.Generic;

using System.Data.SqlClient;
using System.Configuration;

using Firebase1.Storage;
using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using System.Drawing;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Firebase.Storage;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
 
using FireSharp.Response;

using CloudinaryDotNet;
using CloudinaryDotNet.Actions;

using System.Web.Script.Serialization;
using Newtonsoft.Json.Linq;

public partial class pages_trading_process : System.Web.UI.Page
{
     
    public string download_url_str;
    public string   file_full_path;
    public string imgName;
    public string itemID;




    protected void populate_comments(string item_id)
    {



        Table itemTable = new Table(); itemTable.CssClass = "table table-bordered table-hover table-striped table-responsive";
 
   
        foreach (comments comment in getcomments(item_id))
        {
            TableRow newRow = new TableRow();
            TableCell imgCell = new TableCell();
            imgCell.Text = string.Format("<div style='text-align:center;width:100px;display:block;'>" + comment.comment_user_name + "<img style='  height:100px;display:block;width:100px;' src='" + comment.comment_user_img+ "' ></img></div>"); newRow.Cells.Add(imgCell);


            TableCell content_Cell = new TableCell(); content_Cell.Text = comment.comment_content; newRow.Cells.Add(content_Cell);

         

            itemTable.Rows.Add(newRow);
        }
       comment_ph.Controls.Clear();
        comment_ph.Controls.Add(itemTable);

    }

     

    public bool img_flg=true;

    protected void Page_Load(object sender, EventArgs e_)
    {


        if (!IsPostBack)
        {


            if (!string.IsNullOrEmpty(Session["item_id"].ToString()))
            {
                itemID = Session["item_id"].ToString();
               
                populateTradingDetails(getitem(itemID));
                populate_comments(itemID);

            }
        }




    }

   
  

    public barter current_barter_item_obj;

     protected void populateTradingDetails(barter item)
    {//retrieve data from object and populate onto the screen
        id_lbl.Text = Session["item_id"].ToString();

        if (img_flg)
        {
           img.ImageUrl = @""+item.barter_img+"";
        }
         item_name_lbl.Text=item.title.ToString();
         desc_lbl.Text=item.description.ToString();
         longi_lbl.Text=item.longitude.ToString();
         lati_lbl.Text=item.latitude.ToString();
         time_lbl.Text=item.time.ToString();
         type_lbl.Text=item.type.ToString();
         posted_by.Text=item.username.ToString();
         value_lbl.Text=item.value.ToString();
         like_count_lbl.Text = item.like_count.ToString();
 
        /*
          
          
           this.barter_img =barter_img;
   this.description  =description;

   this.latitude  =latitude;
   this.like_count  =like_count;
   this.longitude =longitude;
   this.time =time;
   this.title  =title;
   this.type =type;
  this.uid =uid;
   this.username=username;
   this.value = value;
         */
    }

     protected void delete_current_item(object sender, EventArgs e_) {
         var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Barter_Posts/" + Session["ref_id"].ToString() + "/.json"));
         http.Accept = "application/json";
         http.ContentType = "application/json";
         http.Method = "DELETE";

         var response = http.GetResponse();

         var stream = response.GetResponseStream();
         var sr = new StreamReader(stream);
         var content = sr.ReadToEnd();



         if (Session["type"].ToString().Equals("Services"))
         {
             Response.Redirect("~/pages/Customer/Services.aspx");
         }
         else {
             Response.Redirect("~/pages/Customer/goods.aspx");
         }
        
     }

     private void MessageBoxShow(string message)
     {
         this.AlertBoxMessage.InnerText = message;
         this.AlertBox.Visible = true;
     }
     protected  void btn_delete_click(object sender, EventArgs e_) {




         MessageBoxShow("Are You Sure Want to delete this "+Session["title"].ToString()+"");
         

     }


     private static FireSharp.FirebaseClient _client = db_connection.getFirebaseClientRef();
   
    












     public string barter_img, description, latitude, like_count, longitude, time, title, type, uid, username, value;


     

     protected async void btn_save_click(object sender  ,EventArgs e_) {


         this.description  =desc_lbl.Text.ToString();

         this.latitude = lati_lbl.Text.ToString();
         this.like_count = like_count_lbl.Text.ToString();
         this.longitude = longi_lbl.Text.ToString();
         this.time = time_lbl.Text.ToString();
         this.title = item_name_lbl.Text.ToString();
         this.type = type_lbl.Text.ToString();
         this.uid = Session["uid"].ToString();
         this.username = posted_by.Text.ToString();
         this.value = value_lbl.Text.ToString();

 

         if(FileUpload1.HasFile){
             string s = @"" + FileUpload1.FileName;
         FileUpload1.PostedFile.SaveAs(Server.MapPath(s));
         var uploadParams = new ImageUploadParams()
         {
             File = new FileDescription(@"BarterWorld\pages\Customer\"+s+"")
         };
         var uploadResult = db_connection.cloudinary.Upload(uploadParams);


         var checkParams = new SortedDictionary<string, object>();
         checkParams.Add("public_id", uploadResult.PublicId);
         checkParams.Add("version", uploadResult.Version);
         checkParams.Add("signature", uploadResult.Signature);
         checkParams.Add("width", uploadResult.Width);
         checkParams.Add("height", uploadResult.Height);
         checkParams.Add("format", uploadResult.Format);
         checkParams.Add("resource_type", uploadResult.ResourceType);
         checkParams.Add("created_at", uploadResult.CreatedAt);
         checkParams.Add("bytes", uploadResult.Length);
         checkParams.Add("type", uploadResult.Info);
         checkParams.Add("url", uploadResult.Uri);
         checkParams.Add("secure_url", uploadResult.SecureUri);

         /*
              
              
           "public_id":"tquyfignx5bxcbsupr6a",
"version":1375302801,
"signature":"52ecf23eeb987b3b5a72fa4ade51b1c7a1426a97",
"width":1920,
"height":1200,
"format":"jpg",
"resource_type":"image",
"created_at":"2017-07-31T20:33:21Z",
"bytes":737633,
"type":"upload",
"url":
"http://res.cloudinary.com/demo/image/upload/v1375302801/tquyfignx5bxcbsupr6a.jpg",
"secure_url":
"https://res.cloudinary.com/demo/image/upload/v1375302801/tquyfignx5bxcbsupr6a.jpg"
              
          */

         var api = new Api(db_connection.account);
         string expectedSign_json = api.SignParameters(checkParams);


         Debug.WriteLine("response_url:" + uploadResult.Uri);

        // cloudinaryResponse result = JsonConvert.DeserializeObject<cloudinaryResponse>(uploadResult.ToString());

         download_url_str = uploadResult.Uri.ToString();


         Stream fs = FileUpload1.PostedFile.InputStream;
         BinaryReader br = new BinaryReader(fs);
         byte[] fileBytes = br.ReadBytes((Int32)fs.Length);

         string base64String = Convert.ToBase64String(fileBytes, 0, fileBytes.Length);
         img.ImageUrl = "data:image/png;base64," + base64String;

         Stream stream = new MemoryStream(fileBytes);


         }



         string upload_img_url="";

           if(FileUpload1.PostedFile==null || download_url_str==null || download_url_str==""){

               upload_img_url = Session["barter_img"].ToString();

                    }else{
                        upload_img_url = download_url_str;

                    }




 
                var barter = new barter
                {

    barter_img=upload_img_url,

    description  =this.description,

    latitude  =this.latitude,
    like_count  =this.like_count,
    longitude =this.longitude,
    time =this.time,
    title  =this.title,
    type =this.type,
    uid= Session["uid"].ToString(),
    username=this.username,
    value = this.value
 
                };

                FirebaseResponse response_update = await _client.UpdateAsync("Barter_Posts/" + Session["item_id"].ToString() + "", barter);
                barter barter_updated = response_update.ResultAs<barter>(); //The response will contain the data written


                Debug.WriteLine("json data: " + barter_updated.title);

                 System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('You have just updated Barter Item（"+Session["item_id"].ToString()+"） : "+this.title+"');", true);
           









     }

   



    public  barter getitem(string itemID)
    {
        
        List<barter> barter_get = new List<barter>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Barter_Posts/" + itemID + "/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();

        current_barter_item_obj = JsonConvert.DeserializeObject<barter>(content);

        current_barter_item_obj.ref_id = itemID;

     

        /*
          this.barter_img =barter_img;
    this.description  =description;

    this.latitude  =latitude;
    this.like_count  =like_count;
    this.longitude =longitude;
    this.time =time;
    this.title  =title;
    this.type =type;
   this.uid =uid;
    this.username=username;
    this.value = value;
 
         */
        Session["ref_id"] = current_barter_item_obj.ref_id;
        Session["barter_img"] = current_barter_item_obj.barter_img;
        Session["description"] = current_barter_item_obj.description;
        Session["latitude"] = current_barter_item_obj.latitude;
        Session["like_count"] = current_barter_item_obj.like_count;
        Session["longitude"] = current_barter_item_obj.longitude;
        Session["time"] = current_barter_item_obj.time;
        Session["title"] = current_barter_item_obj.title;
        Session["type"] = current_barter_item_obj.type;
        Session["uid"] = current_barter_item_obj.uid;
        Session["username"] = current_barter_item_obj.username;
        Session["value"] = current_barter_item_obj.value;




        return current_barter_item_obj;
    }



    public List<comments> getcomments(string itemID)
    {

        List<comments> comment_get = new List<comments>();

        var http = (HttpWebRequest)WebRequest.Create(new Uri("https://barterworld-ad75e.firebaseio.com/Comments/" + itemID + "/.json"));
        http.Accept = "application/json";
        http.ContentType = "application/json";
        http.Method = "GET";

        var response = http.GetResponse();

        var stream = response.GetResponseStream();
        var sr = new StreamReader(stream);
        var content = sr.ReadToEnd();


        if (content.ToString() != "null")
        {

            dynamic result = JsonConvert.DeserializeObject<dynamic>(content);

            foreach (JProperty x in (JToken)result)
            {
                // Debug.WriteLine( x.Value.ToString());
                Console.WriteLine("{0}:{1}", x.Name, x.Value.ToString());            // it will print the id:{...content...}
                comments st = JsonConvert.DeserializeObject<comments>(x.Value.ToString());
                st.comment_ref_id = x.Name;

                comment_get.Add(st);

            }

        }
        else {

            comments st = new comments("", "", "http://res.cloudinary.com/barterworld/image/upload/v1505699450/login_qxtbzv.png", "", "No Comments For current Posts Yet");

            comment_get.Add(st);
        }


        /*
          
         */

        return comment_get;
    }


    protected void btn_send_comment_click(object sender, EventArgs e)
    {

        var json = Newtonsoft.Json.JsonConvert.SerializeObject(new
        {
            comment_content = txt_comment.Text.ToString(),
            comment_uid = "admin1",

            comment_user_img = "http://res.cloudinary.com/barterworld/image/upload/v1505692260/admin_jqi4jo.png",
            comment_user_name= "Admin"
        });
        var request = WebRequest.CreateHttp("https://barterworld-ad75e.firebaseio.com/Comments/" + id_lbl.Text.ToString() + "/.json");
        request.Method = "POST";
        request.ContentType = "application/json";
        var buffer = Encoding.UTF8.GetBytes(json);
        request.ContentLength = buffer.Length;
        request.GetRequestStream().Write(buffer, 0, buffer.Length);
        var response = request.GetResponse();
        json = (new StreamReader(response.GetResponseStream())).ReadToEnd();
        // TODO: parse response (contained in `json` variable) as appropriate
       // System.Web.UI.ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox", "alert('" + json + "');", true);

        txt_comment.Text = "";
        Debug.WriteLine(json);
        
        
                populate_comments(id_lbl.Text.ToString());
 
    }




    protected void backBtn_Click(object sender, EventArgs e)
    {
        Response.Redirect("Services.aspx");
    }
    protected void TradingBtn_Click(object sender, EventArgs e)
    {

    }
}
