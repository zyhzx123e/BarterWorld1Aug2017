﻿using System;
using System.Collections.Generic;

using System.Web;

using System.Data.Sql;
using System.Data.SqlClient;

public class administrator  
{
    public string adminid { get; set; }
    public string adminpwd { get; set; }

     
	public administrator()
	{
		
	}
     
  
}