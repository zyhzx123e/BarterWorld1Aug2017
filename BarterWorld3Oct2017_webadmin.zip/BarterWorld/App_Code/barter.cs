﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

/// <summary>
/// Summary description for barter
/// </summary>
public class barter
{
    [JsonIgnore]
	 public string ref_id { get; set; }
    [JsonProperty("barter_img")]
    public string barter_img { get; set; }

    [JsonProperty("description")]
    public string description { get; set; }

    [JsonProperty("latitude")]
    public string latitude { get; set; }

    [JsonProperty("like_count")]
    public string like_count { get; set; }

    [JsonProperty("longitude")]
    public string longitude { get; set; }

    [JsonProperty("time")]
    public string time{ get; set; }

    [JsonProperty("title")]
    public string title { get; set; }

    [JsonProperty("type")]
    public string type { get; set; }

    [JsonProperty("uid")]
    public string uid { get; set; }

    [JsonProperty("username")]
    public string username { get; set; }

    [JsonProperty("value")]
    public string value { get; set; }

    public barter() { }
    public barter(string ref_id,string barter_img,
        string description,string latitude,string like_count,string longitude,string time, string title,
        string type,string uid,string username,string value) 
    {
  this.ref_id =ref_id;
   this.barter_img =barter_img;
    this.description  =description;

    this.latitude  =latitude;
    this.like_count  =like_count;
    this.longitude =longitude;
    this.time =time;
    this.title  =title;
    this.type =type;
   this.uid =uid;
    this.username=username;
    this.value = value;
 
    }
}