﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

/// <summary>
/// Summary description for barter_list
/// </summary>
/// []

public class barter_list
{


    [JsonIgnore]
    public barter barter_item { get; set; }
   
	public barter_list()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}