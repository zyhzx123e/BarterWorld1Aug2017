﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;


using System.Web.UI.WebControls;
using System.Data;

using System.Data.SqlClient;
using System.Configuration;


using Microsoft.Reporting.WebForms;
using Microsoft.Reporting.Common;
using Microsoft.Reporting;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using System.Web.Script.Serialization;

public partial class Master_pages_main : System.Web.UI.MasterPage
{

    public string admin_id_get;
    public string admin_pwd_get;
    public string admin_loggedin_get;

    public Literal user_li { get; set; }



    public string place_user { get; set; }
    public string application { get; set; }
    public string users_online { get; set; }



    protected void Page_Load(object sender, EventArgs e)
    {






        if (!IsPostBack)
        {
            try {

                admin_id_get = Session["id"].ToString();
                admin_pwd_get = Session["pwd"].ToString();
                admin_loggedin_get = Session["loggedin"].ToString();

            }catch(Exception er){

                Debug.WriteLine("error"+er.Message);
            Response.Redirect("~/pages/login.aspx");
        
            
            }


            if (admin_loggedin_get != null)
            {
                if (admin_id_get != null && admin_loggedin_get == "true")
                {

                    hideDiv.Visible = true;
                    userMenu_btn.Text = admin_id_get;
                    populateFunc();

                    Button_pwd_reset.Visible = true;
                    login_btn.Visible = false;
                    logout_btn.Visible = true;

                    btn_viewCustomer.Visible = true;
                    btn_manageUser.Visible = true;

                    //  main.Attributes.Add("bgcolor","#2e6095");


                }

            }
        }
        else {
/*
            btn_viewCustomer.Visible = false;
            btn_manageUser.Visible = false;
            userMenu_btn.Text = "Hi Admin! You havent sign in...";
            hideDiv.Visible = false;
            Button_pwd_reset.Visible = false;*/
        }
     
 PlaceHolder_user.Visible = true;
       

        user_li = new Literal();
        application = Application["TotalApplications"].ToString();
        users_online = Application["TotalUserSessions"].ToString();

        user_li.Text = "<h5>Number of Users Online :  " + users_online + "</h5>";
        ////  Response.Write("Number of Applications : " + Application["TotalApplications"]+" || ");
      string place_user = user_li.Text;
        // Response.Write("Number of Users Online : " + Application["TotalUserSessions"]);


        PlaceHolder_user.Controls.AddAt(0, user_li);

    }

    protected void btn_viewServices_click(object sender, EventArgs e)
    {
        Response.Redirect("~/pages/Customer/Services.aspx");
    }
    protected void btn_viewGoods_click(object sender, EventArgs e)
    {
        Response.Redirect("~/pages/Customer/goods.aspx");
    }

    protected void btn_manageControl_click(object sender, EventArgs e)
    {
      //  Response.Redirect("~/pages/administrator/manageFunc.aspx");
    }
    protected void btn_viewCustomer_click(object sender, EventArgs e)
    {
        Response.Redirect("~/pages/Customer/viewCustomerInfo.aspx");
    
    }
    protected void btn_manageUser_click(object sender, EventArgs e)
    {

        Response.Redirect("~/pages/Customer/manageUser.aspx");
    }

    protected void btn_resetPwd(object sender, EventArgs e) {
        Response.Redirect("~/pages/pwdChange.aspx");
    }

    protected void DisplayTimeEvent(object sender, EventArgs e)
    {

        user_li = new Literal();
        application = Application["TotalApplications"].ToString();
        users_online = Application["TotalUserSessions"].ToString();
        user_li.Text = "<h5>No. of Users Online :  " + users_online + "</h5>";
       
        PlaceHolder_user.Controls.AddAt(0, user_li);
    }

 

    protected void populateFunc() {
        
            btn_viewCustomer.Visible = true;
            btn_manageUser.Visible = true;
            userMenu_btn.Text = "Hi Administrator " + admin_id_get;
           
       
       
        
    
    }

   
    protected void search_Click(object sender, EventArgs e)
    {
        try
        {
            string text = string.Empty;
            System.Text.StringBuilder txtaddress = new System.Text.StringBuilder();
            txtaddress.Append("https://www.shop.com/search/");
            if (searchtxt.Text != string.Empty)
            {
                text = searchtxt.Text.Replace(' ', '+');
                txtaddress.Append(text + ' ' + '+');
            }
            string url = txtaddress.ToString();
           // Response.Redirect(url, false);

            Literal litServices = new Literal();
            litServices.Text = "<div><iframe src='" + url + "' runat ='server' scrolling='yes' width = '1100' height = '500' frameborder='1' style='border:1' allowfullscreen> </iframe> </div>";
            link_services.Controls.Add(litServices);
        }
        catch (Exception ex)
        {
            Response.Redirect(ex.ToString());
        }
    }
}
